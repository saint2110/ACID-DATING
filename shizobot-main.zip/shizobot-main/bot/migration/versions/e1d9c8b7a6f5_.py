"""add goal to ankets

Revision ID: e1d9c8b7a6f5
Revises: c7a3e9d05f12
Create Date: 2026-04-30 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'e1d9c8b7a6f5'
down_revision: Union[str, None] = 'c7a3e9d05f12'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('ankets', sa.Column('goal', sa.SmallInteger(), nullable=True))


def downgrade() -> None:
    op.drop_column('ankets', 'goal')

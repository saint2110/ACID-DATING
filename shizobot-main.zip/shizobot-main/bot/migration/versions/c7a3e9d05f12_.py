"""add audio_file_id to ankets

Revision ID: c7a3e9d05f12
Revises: b1e4d7f23c90
Create Date: 2026-03-28 00:02:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'c7a3e9d05f12'
down_revision: Union[str, None] = 'b1e4d7f23c90'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('ankets', sa.Column('audio_file_id', sa.String(96), nullable=True))


def downgrade() -> None:
    op.drop_column('ankets', 'audio_file_id')

"""add username to ankets, make sender_username nullable

Revision ID: b1e4d7f23c90
Revises: a3f2c8d91b45
Create Date: 2026-03-28 00:01:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b1e4d7f23c90'
down_revision: Union[str, None] = 'a3f2c8d91b45'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('ankets', sa.Column('username', sa.String(34), nullable=True))
    op.alter_column('likes', 'sender_username', nullable=True)


def downgrade() -> None:
    op.alter_column('likes', 'sender_username', nullable=False)
    op.drop_column('ankets', 'username')

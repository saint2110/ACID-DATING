"""add banned column to ankets

Revision ID: a3f2c8d91b45
Revises: 81fb913ab588
Create Date: 2026-03-28 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a3f2c8d91b45'
down_revision: Union[str, None] = '81fb913ab588'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('ankets', sa.Column('banned', sa.Boolean(), nullable=False, server_default='false'))


def downgrade() -> None:
    op.drop_column('ankets', 'banned')

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, delete, func
from db.database import async_connection
from db.models import Anket, MediaFile, Like, Admin

from typing import List, Tuple
import asyncio
import logging
import time

# ---------------------------------------------------------------------------
# In-memory cache для горячих read-запросов (анкеты + медиа)
# При 3000 пользователей: ~1.8MB анкеты + ~1.5MB медиа ≈ 3.3MB
# ---------------------------------------------------------------------------
_CACHE_TTL = 600  # 10 минут, как страховка; основная инвалидация — на запись

_anket_cache: dict[int, tuple] = {}  # {tg_id: (Anket, expires_at)}
_media_cache: dict[int, tuple] = {}  # {tg_id: (list[MediaFile], expires_at)}


def _ac_get(tg_id: int):
    e = _anket_cache.get(tg_id)
    return e[0] if e and time.monotonic() < e[1] else None


def _ac_set(tg_id: int, v):
    _anket_cache[tg_id] = (v, time.monotonic() + _CACHE_TTL)


def _ac_del(tg_id: int):
    _anket_cache.pop(tg_id, None)


def _mc_get(tg_id: int):
    e = _media_cache.get(tg_id)
    return e[0] if e and time.monotonic() < e[1] else None


def _mc_set(tg_id: int, v):
    _media_cache[tg_id] = (v, time.monotonic() + _CACHE_TTL)


def _mc_del(tg_id: int):
    _media_cache.pop(tg_id, None)

@async_connection
async def add_anket(session: AsyncSession, tg_id: int, username: str | None, name: str, age: int,
                    gender: bool, interest: int, city: str, description: str, status: bool,
                    audio_file_id: str | None = None, goal: int | None = None) -> None:
    logging.info(f'add_anket: {tg_id=} {name=} {age=} {gender=} {city=}')
    anket = Anket(id=tg_id, username=username, name=name, age=age, male=gender, interest=interest,
                  city=city, description=description, active=status, audio_file_id=audio_file_id,
                  goal=goal)
    await session.merge(anket)
    await session.commit()
    _ac_del(tg_id)


@async_connection
async def change_anket_audio(session: AsyncSession, tg_id: int, audio_file_id: str | None) -> None:
    user = await session.scalar(select(Anket).filter_by(id=tg_id))
    if not user:
        return
    user.audio_file_id = audio_file_id
    await session.merge(user)
    await session.commit()
    _ac_del(tg_id)


@async_connection
async def change_anket_goal(session: AsyncSession, tg_id: int, goal: int | None) -> None:
    user = await session.scalar(select(Anket).filter_by(id=tg_id))
    if not user:
        return
    user.goal = goal
    await session.merge(user)
    await session.commit()
    _ac_del(tg_id)


@async_connection
async def add_media(session: AsyncSession, tg_id: int, media: List[str], is_video: bool) -> None:
    await session.execute(delete(MediaFile).where(MediaFile.user == tg_id))
    logging.info(f'add_media: {tg_id=} files={media}')
    files_to_save = [MediaFile(user=tg_id, file=file_id, video=is_video) for file_id in media]
    session.add_all(files_to_save)
    await session.commit()
    _mc_del(tg_id)


@async_connection
async def change_anket_status(session: AsyncSession, tg_id: int, status: bool) -> None:
    user = await session.scalar(select(Anket).filter_by(id=tg_id))
    if user:
        user.active = status
        await session.merge(user)
        await session.commit()
    _ac_del(tg_id)


@async_connection
async def change_anket_description(session: AsyncSession, tg_id: int, text: str) -> None:
    user = await session.scalar(select(Anket).filter_by(id=tg_id))
    if not user:
        return
    user.description = text
    await session.merge(user)
    await session.commit()
    _ac_del(tg_id)


@async_connection
async def get_ankets_queue(session: AsyncSession, tg_id: int, n: int) -> List[int]:
    usr = await session.scalar(select(Anket).filter_by(id=tg_id))
    intr = (False, True,) if usr.interest == 2 else (bool(usr.interest),)
    result = await session.execute(
        select(Anket.id)
        .where(
            Anket.id != tg_id,
            Anket.male.in_(intr),
            Anket.active == True,
            Anket.banned == False
        )
        .order_by(func.random())
        .offset(n * 20)
        .limit(20)
    )
    return result.scalars().all()


@async_connection
async def get_users(session: AsyncSession) -> List[int]:
    result = await session.execute(select(Anket.id))
    return result.scalars().all()

@async_connection
async def get_admins(session: AsyncSession) -> List[int]:
    result = await session.execute(select(Admin.id))
    return result.scalars().all()

@async_connection
async def get_anket(session: AsyncSession, tg_id: int) -> Anket | None:
    cached = _ac_get(tg_id)
    if cached is not None:
        return cached
    result = await session.scalar(select(Anket).filter_by(id=tg_id))
    if result is not None:
        _ac_set(tg_id, result)
    return result


@async_connection
async def get_name(session: AsyncSession, tg_id: int) -> str:
    return await session.scalar(select(Anket.name).filter_by(id=tg_id))


@async_connection
async def check_anket_status(session: AsyncSession, tg_id: int) -> bool:
    return await session.scalar(select(Anket.active).filter_by(id=tg_id))


@async_connection
async def get_media(session: AsyncSession, tg_id: int) -> List[MediaFile] | None:
    cached = _mc_get(tg_id)
    if cached is not None:
        return cached
    result = (await session.execute(select(MediaFile).where(MediaFile.user == tg_id))).scalars().all()
    _mc_set(tg_id, result)
    return result


@async_connection
async def get_ankets_data(session: AsyncSession) -> List[Tuple]:
    result = await session.execute(select(Anket.male, Anket.age, Anket.city, Anket.active))
    return result.all()


@async_connection
async def save_like(session: AsyncSession, user_id: int, username: str, anket_id: int, message: str = None) -> bool:
    like = await session.scalar(select(Like).where(Like.sender_id == user_id, Like.recipient_id == anket_id))
    old_like = bool(like)
    if old_like:
        like.sender_username = username
        like.message = message
    else:
        like = Like(sender_id=user_id, sender_username=username, recipient_id=anket_id, message=message)
    await session.merge(like)
    await session.commit()
    return old_like


@async_connection
async def get_likes(session: AsyncSession, tg_id: int) -> List[Like]:
    result = await session.execute(
        select(Like.id, Like.sender_id, Like.message)
        .join(Anket, Like.sender_id == Anket.id)
        .where(
            Like.recipient_id == tg_id,
            Anket.active == True,
            Anket.banned == False
        )
    )
    return result.all()


@async_connection
async def ban_user(session: AsyncSession, tg_id: int) -> bool:
    user = await session.scalar(select(Anket).filter_by(id=tg_id))
    if not user:
        return False
    user.banned = True
    user.active = False
    await session.merge(user)
    await session.commit()
    _ac_del(tg_id)
    return True


@async_connection
async def unban_user(session: AsyncSession, tg_id: int) -> bool:
    user = await session.scalar(select(Anket).filter_by(id=tg_id))
    if not user:
        return False
    user.banned = False
    await session.merge(user)
    await session.commit()
    _ac_del(tg_id)
    return True


@async_connection
async def get_id_by_username(session: AsyncSession, username: str) -> int | None:
    return await session.scalar(
        select(Anket.id).where(Anket.username == username).limit(1)
    )


@async_connection
async def remove_like(session: AsyncSession, like_id: int) -> None:
    like = await session.scalar(select(Like).filter_by(id=like_id))
    await session.delete(like)
    await session.commit()


@async_connection
async def is_admin(session: AsyncSession, tg_id: int) -> bool:
    return bool(await session.scalar(select(Admin).filter_by(id=tg_id)))

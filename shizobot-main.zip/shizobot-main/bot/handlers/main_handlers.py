from aiogram.utils.media_group import MediaGroupBuilder
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import default_state
from aiogram.filters import ChatMemberUpdatedFilter, StateFilter, Command, KICKED
from aiogram.types import Message, ChatMemberUpdated, ReplyKeyboardRemove, ContentType
from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramForbiddenError, TelegramBadRequest
from aiogram.methods.get_chat_member import GetChatMember
from keyboards.admin_panel_keyboards import *
from keyboards.main_keyboards import *
from misc.gecoder import get_city_by_name, get_city_by_cords
from misc.states import RegistrationSteps, MainStates
from middlewares.album_middleware import AlbumMiddleware
from db.requests import *
from create_bot import required_chats, debug, storage
import logging
import html

router = Router()
router.message.middleware(AlbumMiddleware())

GOAL_LABELS = {
    0: '🤝 Дружба',
    1: '💬 Общение',
    2: '🔥 Секс',
    3: '💑 Отношения',
}
GOAL_BUTTONS = {v: k for k, v in GOAL_LABELS.items()}
GOAL_BUTTON_TEXTS = set(GOAL_LABELS.values()) | {'пропустить цель ⏩'}


async def is_subscribed(user_id: int, bot: Bot, message: Message) -> bool:
    """Проверка членства пользователя во ВСЕХ required_chats.
    Если бот не имеет доступа к чату — уведомляет админов и пользователя."""
    if not required_chats or debug:
        return True
    for chat_id in required_chats:
        chat_title = str(chat_id)
        try:
            chat = await bot.get_chat(chat_id)
            chat_title = chat.title or chat_title
        except Exception:
            admins = await get_admins()
            for admin_id in admins:
                try:
                    await bot.send_message(admin_id,
                        f'⚠️ Нет доступа к чату <code>{chat_id}</code>.\n'
                        f'Добавь бота в чат и дай права на проверку участников.')
                except Exception:
                    pass
            await message.answer(
                f'Не удалось проверить подписку на чат <code>{chat_id}</code>. '
                f'Напиши админу.')
            return False

        try:
            member = await bot.get_chat_member(chat_id=chat_id, user_id=user_id)
            if member.status in ('left', 'kicked'):
                return False  # не подписан на этот чат — сразу отказ
        except TelegramBadRequest as e:
            if 'USER_NOT_PARTICIPANT' in str(e) or 'user not found' in str(e).lower():
                return False  # не подписан
            else:
                admins = await get_admins()
                for admin_id in admins:
                    try:
                        await bot.send_message(admin_id,
                            f'⚠️ Бот в чате <b>{chat_title}</b> (<code>{chat_id}</code>), '
                            f'но не может проверять участников.\n'
                            f'Выдай боту права администратора.')
                    except Exception:
                        pass
                logging.warning(f'get_chat_member failed for {chat_id}: {e}')
                return False
    return True  # подписан на все чаты


async def build_subscribe_text(bot: Bot) -> str:
    """Строит текст сообщения о подписке со ссылками на все required_chats."""
    lines = []
    for chat_id in required_chats:
        try:
            chat = await bot.get_chat(chat_id)
            title = chat.title or str(chat_id)
            if chat.username:
                link = f'https://t.me/{chat.username}'
            elif chat.invite_link:
                link = chat.invite_link
            else:
                # Приватный чат без ссылки — генерируем
                link = await bot.export_chat_invite_link(chat_id)
            lines.append(f'• <a href="{link}">{title}</a>')
        except Exception as e:
            logging.warning(f'build_subscribe_text: failed for {chat_id}: {e}')
            lines.append(f'• <code>{chat_id}</code>')
    chats_text = '\n'.join(lines) if lines else '(чаты не настроены)'
    return f'Для использования бота необходимо подписаться:\n{chats_text}'


async def start_search(message: Message, state: FSMContext) -> None:
    """Старт поиска анкет"""
    await state.set_state(MainStates.search)
    await message.answer('🔎✨', reply_markup=search_kb())
    await show_next_anket(message=message, state=state)


async def show_next_anket(message: Message, state: FSMContext) -> None:
    """Просмотр следующей анкеты"""
    viewer = await get_anket(message.from_user.id)
    if viewer and viewer.banned:
        await state.clear()
        await message.answer('Твоя анкета заблокирована. Обратись к администратору.')
        return

    admin_view = bool(await is_admin(message.from_user.id))
    seen_in_pass: set[int] = set()
    while anket_id := await get_anket_from_queue(message.from_user.id, state):
        if anket_id in seen_in_pass:
            break
        seen_in_pass.add(anket_id)
        if await storage.redis.exists(f'dislike:{message.from_user.id}:{anket_id}'):
            continue
        result = await render_anket(anket_id, message, admin_view=admin_view)
        if result is True:
            await state.update_data(processing=anket_id)
            return
        if result is None:
            return
    await message.answer('Анкеты закончились, загляни позже 👀')


async def show_self_anket(message: Message, state: FSMContext) -> None:
    """"Рендер анкеты пользователя и выбор дальнейшего действия"""
    await state.set_state(MainStates.edit_anket_or_start)
    anket = await get_anket(message.from_user.id)
    if not anket:
        await start(message=message, state=state)
        return
    if anket.banned:
        await message.answer('Твоя анкета заблокирована. Обратись к администратору.')
        return
    await message.answer(text='Так выглядит твоя анкета:')
    await render_anket(message.from_user.id, message)
    await message.answer('1. Смотреть анкеты.\n2. Заполнить анкету заново.\n3. Изменить фото/видео.\n'
                        '4. Изменить текст анкеты.\n5. Изменить музыку 🎵\n6. Изменить цель 🎯', reply_markup=edit_anket_kb())


async def render_anket(anket_id, message: Message, pre_text='', after_text='', start_chat=False, admin_view=False) -> bool:
    """Рендер анкеты. Возвращает False если анкета недоступна."""
    anket = await get_anket(anket_id)
    if not anket or anket.banned:
        return False
    media_list = await get_media(anket_id)
    if not media_list:
        logging.warning(f'render_anket: no media for {anket_id}')
        return False
    CAPTION_LIMIT = 1024
    city = f', {html.escape(anket.city)}' if anket.city else ''
    admin_info = f'\n\n👁 ID: <code>{anket_id}</code>' if admin_view else ''
    goal_text = f'\n🎯 {GOAL_LABELS[anket.goal]}' if anket.goal is not None else ''
    anket_text = f'{pre_text}{html.escape(anket.name)}, {anket.age}{city} - {html.escape(anket.description)}{goal_text}{after_text}{admin_info}'
    caption_fits = len(anket_text) <= CAPTION_LIMIT
    try:
        if media_list[0].video:
            await message.answer_video(
                video=media_list[0].file,
                caption=anket_text if caption_fits else None
            )
        else:
            album_builder = MediaGroupBuilder(caption=anket_text if caption_fits else None)
            for media in media_list:
                album_builder.add_photo(media=media.file)
            album = album_builder.build()
            await message.answer_media_group(media=album)
    except (TelegramBadRequest, TelegramForbiddenError) as e:
        if 'USER_IS_BLOCKED' in str(e) or isinstance(e, TelegramForbiddenError):
            logging.warning(f'render_anket: viewer blocked bot, skipping (anket {anket_id})')
            return None
        logging.warning(f'render_anket: bad file_id for anket {anket_id}: {e}')
        return False
    if not caption_fits:
        await message.answer(anket_text)

    if anket.audio_file_id:
        try:
            await message.answer_audio(audio=anket.audio_file_id)
        except TelegramBadRequest as e:
            logging.warning(f'render_anket: bad audio file_id for anket {anket_id}: {e}')
    if start_chat:
        try:
            await message.answer(text='<b>Начинай общаться 👇</b>', reply_markup=start_chat_kb(anket_id, anket.name))
        except TelegramBadRequest:
            username = f'@{anket.username}' if anket.username else html.escape(anket.name)
            await message.answer(text=f'<b>Начинай общаться 👇</b>\n{username}')
    return True


async def get_anket_from_queue(tg_id: int, state: FSMContext) -> int | None:
    """Получение следующей анкеты из стека"""
    data = await state.get_data()
    queue, offset = data.get('queue', []), data.get('offset', 0)
    try: # пробуем получить анкету из стека
        anket_id = queue.pop(0)
        await state.update_data(queue=queue)
        return anket_id

    except IndexError: # если стек исчерпан
        offset += 1 # увеличиваем смещение на 1

        offsets = (offset, 0) if offset != 0 else (0,)
        for i in offsets: # пробуем найти анкеты в бд с увеличенным или нулевым смещением
            ankets_queue = await get_ankets_queue(tg_id, i)
            if ankets_queue:
                anket_id = ankets_queue[0]
                await state.update_data(queue=ankets_queue[1:], offset=i)
                return anket_id

        return None # возвращаем None если анкет не найдено


@router.message(Command('start'))
async def start(message: Message, state: FSMContext) -> None:
    """Старт бота или вызов главного меню"""
    await state.clear()
    if not await get_anket(message.from_user.id):
        await state.clear()
        await state.set_state(RegistrationSteps.start)
        await message.answer('добро пожаловать в клуб знакомств шизоцелов!', reply_markup=start_bot_kb())
    else:
        await menu(message, state)
    


@router.message(Command('menu'))
async def menu(message: Message, state: FSMContext, reciprocity=False) -> None:
    """Меню выбора основных опций"""
    if await get_anket(message.from_user.id) or reciprocity:
        await state.set_state(MainStates.option_selection)
        await message.answer('1. Смотреть анкеты.\n2. Моя анкета.\n3. Я больше не хочу никого искать.\n4. Донат админу', reply_markup=main_options_kb())
    else:
        await start(message=message, state=state)


@router.message(F.text == 'начать', StateFilter(RegistrationSteps.start))
async def age_request(message: Message, state: FSMContext) -> None:
    """Старт регистрации, запрос возраста"""
    if message.from_user.username:
        await state.set_state(RegistrationSteps.age_request)
        await message.answer('Сколько тебе лет?', reply_markup=ReplyKeyboardRemove())
    else:
        await message.answer(text='Сделай доступным свой юзернейм и попробуй снова')


@router.message(StateFilter(RegistrationSteps.age_request))
async def gender_request(message: Message, state: FSMContext) -> None:
    """Проверка валидности возраста, запрос пола"""
    if not message.text or not message.text.strip().isdigit() or int(message.text) not in range(14, 60):
        await message.answer('<b>Введи корректное число!</b>')
    else:
        await state.update_data(age=int(message.text.strip()))
        await state.set_state(RegistrationSteps.gender_request)
        await message.answer('Твоя половая принадлежность?', reply_markup=gender_selection_kb())


@router.message(F.text.in_(('парень', 'девушка')), StateFilter(RegistrationSteps.gender_request))
async def interest_request(message: Message, state: FSMContext) -> None:
    """Уточнение интереса"""
    await state.update_data(gender=message.text == 'парень')
    await state.set_state(RegistrationSteps.interest_request)
    await message.answer('А кого хочешь найти?', reply_markup=interest_selection_kb())


@router.message(F.text.in_(('девушку', 'парня', 'всё равно')), StateFilter(RegistrationSteps.interest_request))
async def location_request(message: Message, state: FSMContext) -> None:
    """Запрос города"""
    await state.update_data(interest=('девушку', 'парня', 'всё равно').index(message.text))
    await state.set_state(RegistrationSteps.location_request)
    await message.answer('Окей, напиши свой город или отправь геопозицию, чтобы найти шизов рядом', reply_markup=location_request_kb())


@router.message(F.content_type.in_({'text', 'location'}), StateFilter(RegistrationSteps.location_request))
async def name_request(message: Message, state: FSMContext) -> None:
    """Проверка города и запрос имени"""
    city_name = None
    if message.content_type == ContentType.LOCATION:
        msg = await message.answer(text='<i>Идёт доксинг...</i>', reply_markup=ReplyKeyboardRemove())
        latitude, longitude = message.location.latitude, message.location.longitude
        city_name = await get_city_by_cords(latitude, longitude)
        await msg.reply(text='<b>Успешно сватнул адрес!</b>') if city_name else await message.answer(text='Что-то пошло не так, будем считать что у тебя нет города.')

    elif message.text != 'пропустить ⏩':
        msg = await message.answer(text='<i>Идёт доксинг...</i>', reply_markup=ReplyKeyboardRemove())
        city_name = await get_city_by_name(message.text.strip())
        await msg.reply(text='<b>Пополнил базы osint ботов!</b>') if city_name else await message.answer(text='Что-то пошло не так, будем считать что у тебя нет города.')

    await state.update_data(city=city_name)
    await state.set_state(RegistrationSteps.name_request)
    await message.answer(text='Как мне к тебе обращаться?', reply_markup=ReplyKeyboardRemove())


@router.message(F.text, StateFilter(RegistrationSteps.name_request))
async def description_request(message: Message, state: FSMContext) -> None:
    """Проверка валидности имени и запрос текста анкеты"""
    if len(message.text) <= 32:
        await state.update_data(name=message.text.strip())
        await state.set_state(RegistrationSteps.description_request)
        await message.answer(text='Красивое имя, теперь расскажи о себе и желательно в деталях.')
    else:
        await message.answer(text='У тебя длинное имя, я не запомню, попробуй ещё раз.')


@router.message(F.text, StateFilter(RegistrationSteps.description_request))
async def media_request(message: Message, state: FSMContext) -> None:
    """Проверка валидности текста анкеты и запрос медиа"""
    if len(message.text) <= 2048:
        data = await state.get_data()
        await message.answer(text='Отлично, теперь пришли фото или видео' if not data.get('editing_media') else 'Пришли фото или видео')
        await state.update_data(description=message.text.strip(), media=[])
        await state.set_state(RegistrationSteps.media_confirmation)
    else:
        await message.answer(text='А не многовато-ли информации? Давай покороче как-то, попробуй ещё раз.')


@router.message(F.content_type.in_({'photo', 'video', 'text'}), StateFilter(RegistrationSteps.media_confirmation))
async def media_confirmation(message: Message, state: FSMContext) -> None:
    """Сохранение медиа"""
    data = await state.get_data()
  
    if message.content_type == ContentType.VIDEO and not data.get('media'):
        if not data.get('editing_media'):
            await state.update_data(media=[message.video.file_id], video=True)
            await audio_request_step(message=message, state=state)
        else:
            await add_media(tg_id=message.from_user.id, media=[message.video.file_id], is_video=True)
            await show_self_anket(message=message, state=state)

    elif message.content_type == ContentType.PHOTO:
        new_media = data['media'] + [message.photo[-1].file_id]
        if len(new_media) < 3:
            await state.update_data(media=new_media)
            await message.answer(text=f'Фото добавлено {len(new_media)} из 3. Добавить ещё?', reply_markup=add_photo_confirmation_kb())
        elif not data.get('editing_media'):
            await state.update_data(media=new_media, video=False)
            await audio_request_step(message=message, state=state)
        else:
            await add_media(tg_id=message.from_user.id, media=new_media, is_video=False)
            await show_self_anket(message=message, state=state)

    elif message.content_type == ContentType.TEXT:
        if message.text == 'это все, сохранить фото':
            if not data.get('editing_media'):
                await state.update_data(video=False)
                await audio_request_step(message=message, state=state)
            else:
                await add_media(tg_id=message.from_user.id, media=data['media'], is_video=False)
                await show_self_anket(message=message, state=state)


AUDIO_SIZE_LIMIT = 20 * 1024 * 1024  # 20 МБ в байтах


async def audio_request_step(message: Message, state: FSMContext) -> None:
    """Запрос музыки для анкеты"""
    await state.set_state(RegistrationSteps.audio_request)
    await message.answer(
        '🎵 Хочешь добавить музыку к анкете? Пришли MP3-файл (до 20 МБ).',
        reply_markup=audio_request_kb()
    )


async def goal_request_step(message: Message, state: FSMContext) -> None:
    """Запрос цели анкеты"""
    await state.set_state(RegistrationSteps.goal_request)
    await message.answer(
        '🎯 Выбери цель знакомства:',
        reply_markup=goal_request_kb()
    )


@router.message(StateFilter(RegistrationSteps.audio_request))
async def handle_audio_request(message: Message, state: FSMContext) -> None:
    """Обработка загрузки музыки при регистрации"""
    if message.content_type == ContentType.TEXT and message.text in ('пропустить музыку ⏩', 'удалить музыку 🗑'):
        await state.update_data(audio_file_id=None)
        await goal_request_step(message=message, state=state)

    elif message.content_type == ContentType.AUDIO:
        if message.audio.file_size > AUDIO_SIZE_LIMIT:
            await message.answer('Файл слишком большой, максимум 20 МБ. Попробуй ещё раз.')
            return
        await state.update_data(audio_file_id=message.audio.file_id)
        await goal_request_step(message=message, state=state)

    else:
        await message.answer('Пришли MP3-файл или нажми «пропустить музыку ⏩».')


@router.message(F.text.in_(GOAL_BUTTON_TEXTS), StateFilter(RegistrationSteps.goal_request))
async def handle_goal_request(message: Message, state: FSMContext) -> None:
    """Обработка выбора цели анкеты"""
    goal = GOAL_BUTTONS.get(message.text)  # None if пропустить
    await state.update_data(goal=goal)
    await anket_confirmation(message=message, state=state)


@router.message(StateFilter(RegistrationSteps.goal_request))
async def handle_goal_request_fallback(message: Message, state: FSMContext) -> None:
    await message.answer('Выбери цель знакомства из кнопок ниже 👇', reply_markup=goal_request_kb())


async def anket_confirmation(message: Message, state: FSMContext) -> None:
    """Подтверждение данных для анкеты"""
    data = await state.get_data()
    name_and_age = f'{html.escape(data["name"])}, {data["age"]}'
    main_info = f'{name_and_age}, {html.escape(data["city"])}' if data['city'] else name_and_age
    description, media = data['description'], data['media']
    CAPTION_LIMIT = 1024
    goal = data.get('goal')
    goal_text = f'\n🎯 {GOAL_LABELS[goal]}' if goal is not None else ''
    anket_text = f'{main_info} – {html.escape(description)}{goal_text}'
    caption_fits = len(anket_text) <= CAPTION_LIMIT
    await message.answer(text='<i>Так выглядит твоя анкета:</i>')

    if not data.get('video'):
        album_builder = MediaGroupBuilder(caption=anket_text if caption_fits else None)
        for id in media:
            album_builder.add_photo(media=id)
        album = album_builder.build()
        await message.answer_media_group(media=album)
    else:
        await message.answer_video(video=media[0], caption=anket_text if caption_fits else None)
    if not caption_fits:
        await message.answer(anket_text)
    if data.get('audio_file_id'):
        await message.answer_audio(audio=data['audio_file_id'])
    await state.set_state(RegistrationSteps.anket_confirmation)
    await message.answer(text='Всё верно?', reply_markup=anket_confirmation_kb())


@router.message(F.text.in_(('да', 'изменить анкету')), StateFilter(RegistrationSteps.anket_confirmation))
async def anket_saving(message: Message, state: FSMContext) -> None:
    """Сохранение анкеты"""
    data = await state.get_data()
    status = message.text == 'да'
    await add_anket(tg_id=message.from_user.id, username=message.from_user.username,
                    name=data['name'], age=data['age'], gender=data['gender'],
                    interest=data['interest'], city=data['city'], description=data['description'],
                    status=status, audio_file_id=data.get('audio_file_id'),
                    goal=data.get('goal'))
    await add_media(tg_id=message.from_user.id, media=data['media'], is_video=data.get('video', False))
    await state.clear()

    await state.set_state(MainStates.edit_anket_or_start)
    await message.answer('1. Смотреть анкеты.\n2. Заполнить анкету заново.\n3. Изменить фото/видео.\n'
                        '4. Изменить текст анкеты.\n5. Изменить музыку 🎵\n6. Изменить цель 🎯', reply_markup=edit_anket_kb())
        

@router.message(StateFilter(MainStates.subscription_check))
async def check_subscription(message: Message, state: FSMContext, bot: Bot):
    """Проверка подписки на канал"""
    if message.text == 'я подписался':
        if not await is_subscribed(message.from_user.id, bot, message):
            await message.answer(text='У меня другое мнение на этот счёт, подпишись и пробуй снова.')
        else:
            await state.set_state(MainStates.option_selection)
            await message.answer('1. Смотреть анкеты.\n2. Моя анкета.\n3. Я больше не хочу никого искать.\n4. Донат админу', reply_markup=main_options_kb())


@router.message(F.text.in_(('1🚀', '2', '3', '4', '5', '6')), StateFilter(MainStates.edit_anket_or_start))
async def start_search_or_edit_anket(message: Message, state: FSMContext, bot: Bot) -> None:
    """Опции редактирования анкеты или старт поиска анкет"""
    match message.text:
        case '1🚀': # проверка подписки и старт поиска анкет
            if not await is_subscribed(message.from_user.id, bot, message):
                await state.set_state(MainStates.subscription_check)
                await message.answer(text=await build_subscribe_text(bot), reply_markup=subscribe_confirm())

            else:
                data = await state.get_data()
                await change_anket_status(message.from_user.id, True)
                if 'queue' in data.keys():
                    await start_search(message=message, state=state)

                else:
                    ankets_queue = await get_ankets_queue(message.from_user.id, 0)
                    if not ankets_queue:
                        await message.answer('Не нашёл подходящих анкет')
                        await message.answer('1. Смотреть анкеты.\n2. Заполнить анкету заново.\n3. '
                                            'Изменить фото/видео.\n4. Изменить текст анкеты.',
                                            reply_markup=main_options_kb())
                    else:
                        await state.update_data(queue=ankets_queue, offset=0)
                        await start_search(message=message, state=state)

        case '2': # заполнение анкеты с начала
            await age_request(message=message, state=state)

        case '3': # изменение фото/видео анкеты
            await state.update_data(editing_media=True)
            await media_request(message=message, state=state)
        
        case '4': # редактирование текста анкеты
            await state.set_state(MainStates.description_edit)
            await message.answer(text='Расскажи о себе и желательно в деталях', reply_markup=back_kb())

        case '5': # редактирование музыки
            await state.set_state(MainStates.audio_edit)
            await message.answer('Пришли новый MP3-файл (до 20 МБ) или удали текущий.', reply_markup=audio_request_kb())

        case '6': # редактирование цели
            await state.set_state(MainStates.goal_edit)
            await message.answer('Выбери новую цель знакомства:', reply_markup=goal_request_kb())


@router.message(StateFilter(MainStates.description_edit))
async def anket_description_edit(message: Message, state: FSMContext) -> None:
    """Редактирование текста анкеты"""
    if message.text == 'назад':
        await show_self_anket(message=message, state=state)
    elif message.text and len(message.text) <= 2048:
        await change_anket_description(tg_id=message.from_user.id, text=message.text)
        await show_self_anket(message=message, state=state)
    else:
        await message.answer(text='А не многова-то ли информации? Давай покороче как-то, попробуй ещё раз.')


@router.message(StateFilter(MainStates.audio_edit))
async def anket_audio_edit(message: Message, state: FSMContext) -> None:
    """Редактирование музыки анкеты"""
    if message.text in ('назад', 'пропустить музыку ⏩'):
        await show_self_anket(message=message, state=state)
    elif message.text == 'удалить музыку 🗑':
        await change_anket_audio(tg_id=message.from_user.id, audio_file_id=None)
        await show_self_anket(message=message, state=state)
    elif message.content_type == ContentType.AUDIO:
        if message.audio.file_size > AUDIO_SIZE_LIMIT:
            await message.answer('Файл слишком большой, максимум 20 МБ. Попробуй ещё раз.')
            return
        await change_anket_audio(tg_id=message.from_user.id, audio_file_id=message.audio.file_id)
        await show_self_anket(message=message, state=state)
    else:
        await message.answer('Пришли MP3-файл или нажми «удалить музыку 🗑».')


@router.message(F.text.in_(GOAL_BUTTON_TEXTS), StateFilter(MainStates.goal_edit))
async def anket_goal_edit(message: Message, state: FSMContext) -> None:
    """Редактирование цели анкеты"""
    goal = GOAL_BUTTONS.get(message.text)  # None для пропустить
    await change_anket_goal(tg_id=message.from_user.id, goal=goal)
    await show_self_anket(message=message, state=state)


@router.message(StateFilter(MainStates.goal_edit))
async def anket_goal_edit_fallback(message: Message, state: FSMContext) -> None:
    await message.answer('Выбери цель из кнопок ниже 👇', reply_markup=goal_request_kb())


@router.message(F.text.in_(('1🚀', '2', '3', '4')), StateFilter(MainStates.option_selection))
async def main_options(message: Message, state: FSMContext, bot: Bot) -> None:
    """Основные опции"""
    match message.text:
        case '1🚀': # проверка подписки и старт поиска анкет
            if not await is_subscribed(message.from_user.id, bot, message):
                await state.set_state(MainStates.subscription_check)
                await message.answer(text=await build_subscribe_text(bot), reply_markup=subscribe_confirm())

            else:
                data = await state.get_data()
                await change_anket_status(message.from_user.id, True)

                if 'queue' in data.keys():
                    await start_search(message=message, state=state)

                else:
                    ankets_queue = await get_ankets_queue(message.from_user.id, 0)
                    if ankets_queue:
                        await state.update_data(queue=ankets_queue, offset=0)
                        await start_search(message=message, state=state)

                    else:
                        await message.answer('Не нашёл подходящих анкет')
                        await message.answer('1. Смотреть анкеты.\n2. Моя анкета.\n3. Я больше не хочу никого искать.\n4. Донат админу', reply_markup=main_options_kb())

        case '2': # показ анкеты пользователя
            await show_self_anket(message=message, state=state)

        case '3': # отключение анкеты
            await state.set_state(MainStates.anket_state_switch)
            await message.answer(text='Отключить анкету? Так ты не узнаешь, кому ты понравился.',
                                 reply_markup=turn_anket_off_kb())

        case '4': # донат
            await state.clear()
            await message.answer(text="""btc bc1qc9uytgzvfshyen7hh8s8p8mjv8fzun0srrm2sg
Usdt erc20/любой эфир 0x979675CF0b466622BbfF12A439e68Bf270C2fB79
Usdt tron/любой трон TFXRA3DwLcKJhEvZPXVNaHj5jxWLUieepc\n
https://pay.cloudtips.ru/p/7388827b\n
2204 1801 2054 9688 - карта цупис банк\n""", reply_markup=call_menu_kb())


@router.message(F.text.in_(('❤️', '💌', '👎', '💤', '🚩')), StateFilter(MainStates.search))
async def search(message: Message, state: FSMContext, bot: Bot) -> None:
    """Оценка анкет"""
    viewer = await get_anket(message.from_user.id)
    if viewer and viewer.banned:
        await state.clear()
        await message.answer('Твоя анкета заблокирована. Обратись к администратору.')
        return

    match message.text:
        case '👎':
            data = await state.get_data()
            processing = data.get('processing')
            if processing:
                await storage.redis.setex(f'dislike:{message.from_user.id}:{processing}', 86400, '1')
            await show_next_anket(message, state)

        case '❤️': # лайк
            data = await state.get_data()
            processing = data.get('processing')
            if processing and await check_anket_status(tg_id=processing):
                if not await save_like(message.from_user.id, username=message.from_user.username, anket_id=processing):
                    await bot.send_message(chat_id=processing, text='Кому-то понравилась твоя анкета', reply_markup=likes_watch_kb())
            await show_next_anket(message, state)

        case '💌': # сообщение
            await state.set_state(MainStates.message_request)
            await message.answer('Напиши сообщение для этого пользователя', reply_markup=back_kb())

        case '💤': # возврат в меню
            await state.set_state(MainStates.option_selection)
            await message.answer('Подождём пока твою анкету кто-то увидит')
            await message.answer('1. Смотреть анкеты.\n2. Моя анкета.\n3. Я больше не хочу никого искать.\n4. Донат админу', reply_markup=main_options_kb())

        case '🚩': # репорт на анкету
            data = await state.get_data()
            if data.get('processing'):
                await state.set_state(MainStates.report_request)
                await message.answer('Напиши причину жалобы', reply_markup=back_kb())
            else:
                await show_next_anket(message, state)


@router.message(F.text == 'посмотреть')
async def start_like_answer(message: Message, state: FSMContext) -> None:
    """Просмотр анкет людей, которым понравился пользователь"""
    await message.answer(text='🔎📑', reply_markup=likes_dislike_kb())
    likes_queue = [list(like) for like in await get_likes(message.from_user.id)]
    try:
        like = likes_queue.pop(0)
        person_id, message_text = like[1:]
        pre_text = '<b>Кому-то понравилась твоя анкета:</b>'
        pre_text += f'(и ещё {len(likes_queue)})\n\n' if len(likes_queue) >= 1 else '\n\n'
        after_text = f'\n\n💌 <b>Сообщение для тебя:</b>\n{html.escape(message_text)}' if message_text else ''
        rendered = await render_anket(anket_id=person_id, message=message, pre_text=pre_text, after_text=after_text)
        if rendered is None:
            return
        if rendered is False:
            await remove_like(like[0])
            await message.answer('Анкета недоступна.')
            if likes_queue:
                await start_like_answer(message, state)
            else:
                await menu(message=message, state=state)
            return
        await state.set_state(MainStates.likes_answer)
        await state.update_data(processing=like, likes=likes_queue)

    except IndexError:
        await message.answer(text='Уже неактуально 😔')
        await menu(message=message, state=state)


@router.message(F.text.in_(('❤️', '👎')), StateFilter(MainStates.likes_answer))
async def like_answer(message: Message, state: FSMContext, bot: Bot) -> None:
    """Ответ на лайки"""
    data = await state.get_data()
    like_id, person_id = data['processing'][:2]

    if message.text == '❤️':
        anket = await get_anket(tg_id=person_id)
        if anket and not anket.banned:
            try:
                await message.answer(text=f'<b>Начинай общаться 👇</b>', reply_markup=start_chat_kb(person_id, anket.name))
            except TelegramBadRequest:
                username = f'@{anket.username}' if anket.username else html.escape(anket.name)
                await message.answer(text=f'<b>Начинай общаться 👇</b>\n{username}')
            try:
                msg = await bot.send_message(person_id, text=f'<b>Есть взаимная симпатия!</b>')
                await render_anket(anket_id=message.from_user.id, message=msg, start_chat=True)
                await bot.send_message(person_id, text=f'Дём дальше?', reply_markup=call_menu_kb())
            except TelegramForbiddenError:
                pass
        else:
            await message.answer('Анкета этого пользователя больше недоступна.')

    await remove_like(like_id)
    likes_queue = data['likes']

    if len(likes_queue) >= 1:
        like = likes_queue.pop(0)
        person_id, message_text = like[1:]
        pre_text = '<b>Кому-то понравилась твоя анкета</b>'
        pre_text += f'(и ещё {len(likes_queue)})\n\n' if len(likes_queue) >= 1 else '\n\n'
        after_text = f'\n\n💌 <b>Сообщение для тебя:</b>\n{html.escape(message_text)}' if message_text else ''
        await state.update_data(processing=like, likes=likes_queue)
        await render_anket(like[1], message, pre_text, after_text)

    else:
        await menu(message=message, state=state)


@router.message(F.text, StateFilter(MainStates.message_request))
async def message_request(message: Message, state: FSMContext, bot: Bot) -> None:
    """Отправка сообщения симпатии"""
    data = await state.get_data()

    processing = data.get('processing')
    if message.text == 'назад':
        await state.set_state(MainStates.search)
        await message.answer(text='🔎✨', reply_markup=search_kb())
        if processing:
            await render_anket(processing, message)

    else:
        if processing and await check_anket_status(tg_id=processing):
            if not await save_like(message.from_user.id, message.from_user.username, processing, message.text):
                await bot.send_message(chat_id=processing, text='Кому-то понравилась твоя анкета', reply_markup=likes_watch_kb())
        await message.answer(text='Сообщение отправлено', reply_markup=search_kb())
        await state.set_state(MainStates.search)
        await show_next_anket(message, state)


@router.message(F.text, StateFilter(MainStates.report_request))
async def report_request(message: Message, state: FSMContext, bot: Bot) -> None:
    """Обработка жалобы на анкету"""
    data = await state.get_data()
    processing = data.get('processing')

    if message.text == 'назад':
        await state.set_state(MainStates.search)
        await message.answer(text='🔎✨', reply_markup=search_kb())
        if processing:
            await render_anket(processing, message)
        return

    if not processing:
        await state.set_state(MainStates.search)
        await message.answer(text='🔎✨', reply_markup=search_kb())
        await show_next_anket(message, state)
        return

    REPORT_REASON_LIMIT = 500
    reason_raw = message.text
    if len(reason_raw) > REPORT_REASON_LIMIT:
        await message.answer(f'Причина слишком длинная, напиши покороче (до {REPORT_REASON_LIMIT} символов).')
        return

    reporter = message.from_user
    reporter_info = f'@{reporter.username}' if reporter.username else f'id <code>{reporter.id}</code>'
    reason_escaped = html.escape(reason_raw)
    report_header = (
        f'🚩 <b>Жалоба на анкету</b>\n'
        f'От: {reporter_info} (<code>{reporter.id}</code>)\n'
        f'Причина: {reason_escaped}'
    )
    # Telegram message limit is 4096 chars
    if len(report_header) > 4096:
        report_header = report_header[:4093] + '...'
    admins = await get_admins()
    for admin_id in admins:
        try:
            await bot.send_message(admin_id, report_header)
            await render_anket(processing, await bot.send_message(admin_id, '👇 Анкета:'), admin_view=True)
        except Exception:
            pass

    await message.answer('Жалоба отправлена, спасибо.', reply_markup=search_kb())
    await state.set_state(MainStates.search)
    await show_next_anket(message, state)


@router.message(F.text, StateFilter(MainStates.anket_state_switch))
async def anket_state_switch(message: Message, state: FSMContext) -> None:
    """Отключение анкеты"""
    match message.text:
        case 'отключить анкету 😴':
            await change_anket_status(message.from_user.id, False)
            await message.answer('Отключил твою анкету.',
                                reply_markup=turn_anket_on_kb())
            
        case 'включить анкету' | 'назад':
            await menu(message=message, state=state)


@router.my_chat_member(ChatMemberUpdatedFilter(member_status_changed=KICKED))
async def process_user_blocked_bot(event: ChatMemberUpdated) -> None:
    """Отключение анкеты при блокировке бота"""
    await change_anket_status(tg_id=event.from_user.id, status=False)

@router.message(F.text == '🔗 Получить VPN')
async def get_vpn_link(message: Message):
    await message.answer(
        '🔗 Получить VPN: https://t.me/MadokaVPN_bot?start=ref_8162887420'
    )
@router.message(F.text, StateFilter(default_state))
async def spare_menu_call(message: Message, state: FSMContext):
    """Вызов меню если состояние fsm не определено"""
    await menu(message=message, state=state)
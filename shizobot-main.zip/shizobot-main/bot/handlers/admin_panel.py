from aiogram.utils.media_group import MediaGroupBuilder
from aiogram.fsm.context import FSMContext
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter, TelegramBadRequest
from aiogram.filters import StateFilter, Command
from aiogram.types import CallbackQuery, Message, ContentType
from aiogram import Bot, Router, F

from keyboards.admin_panel_keyboards import *
from middlewares.album_middleware import AlbumMiddleware
from middlewares.admin_filter import AdminAccessMiddleware
from misc.states import AdminPanelStates
from db.requests import *
import asyncio

router = Router()
router.message.middleware(AdminAccessMiddleware())
router.message.middleware(AlbumMiddleware())
router.callback_query.middleware(AdminAccessMiddleware())


@router.message(Command('admin'))
async def admin(message: Message) -> None:
    await message.answer(text=f'Админ панель к вашим услугам, {message.from_user.first_name}.', reply_markup=admin_panel_kb())


@router.callback_query(F.data == 'back')
async def admin_panel_back(callback: CallbackQuery, state: FSMContext, bot: Bot) -> None:
    notification_data = await state.get_data()
    to_delete = notification_data.get('to_delete')
    if isinstance(to_delete, dict):
        try:
            await bot.delete_message(chat_id=to_delete['chat_id'], message_id=to_delete['message_id'])
        except Exception:
            pass
    elif isinstance(to_delete, list):
        for item in to_delete:
            try:
                await bot.delete_message(chat_id=item['chat_id'], message_id=item['message_id'])
            except Exception:
                pass

    if callback.message.content_type == ContentType.TEXT:
        await callback.message.edit_text(text=f'Админ панель к вашим услугам, {callback.from_user.first_name}.',
                                         reply_markup=admin_panel_kb())
    else:
        await callback.message.delete()
        await callback.message.answer(text=f'Админ панель к вашим услугам, {callback.from_user.first_name}.',
                                      reply_markup=admin_panel_kb())
    await state.clear()


@router.callback_query(F.data == 'start_notification')
async def notification_message_request(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AdminPanelStates.message_request)
    await callback.message.edit_text(text='отправьте сообщение для дальнейшей рассылки',
                                     reply_markup=back_to_admin_kb())


@router.message(StateFilter(AdminPanelStates.message_request))
async def notification_message_confirm(message: Message, state: FSMContext, album: list = None) -> None:
    if album:
        notification_text = album[0].caption if album[0].caption else ''
        album_builder = MediaGroupBuilder(caption=notification_text)

        for ms in album:
            if ms.photo:
                album_builder.add_photo(media=ms.photo[0].file_id)
            elif ms.video:
                album_builder.add_video(media=ms.video.file_id)

        album = album_builder.build()
        msg = await message.answer_media_group(media=album)
        to_delete = [{'chat_id': m.chat.id, 'message_id': m.message_id} for m in msg]
        await state.update_data(to_delete=to_delete, contains_album=True, file_id=album)
        await message.answer(text='<i>Подтвердите отправку сообщения</i>', reply_markup=notification_confirmation_kb())

    else:
        # Сохраняем только ID, а не объект Message
        await state.update_data(
            msg_chat_id=message.chat.id,
            msg_message_id=message.message_id
        )
        if message.content_type == ContentType.VIDEO_NOTE:
            msg = await message.send_copy(chat_id=message.from_user.id)
            await state.update_data(
                to_delete={'chat_id': msg.chat.id, 'message_id': msg.message_id},
                file_id=message.video_note.file_id
            )
            await message.answer(text='<i>Подтвердите отправку сообщения</i>',
                                 reply_markup=notification_confirmation_kb())
        elif message.content_type in (ContentType.TEXT, ContentType.PHOTO, ContentType.VIDEO,
                                      ContentType.DOCUMENT, ContentType.VOICE):
            await message.send_copy(chat_id=message.from_user.id, reply_markup=notification_confirmation_kb())
        else:
            await message.answer(text='<i>Неподдерживаемый тип сообщения</i>')

    await state.set_state(AdminPanelStates.notification_start)


@router.callback_query(F.data == 'send', StateFilter(AdminPanelStates.notification_start))
async def notifaction_start(callback: CallbackQuery, state: FSMContext, bot: Bot) -> None:
    notification_data = await state.get_data()

    to_delete = notification_data.get('to_delete')
    await callback.message.delete()

    if isinstance(to_delete, dict):
        try:
            await bot.delete_message(chat_id=to_delete['chat_id'], message_id=to_delete['message_id'])
        except Exception:
            pass
    elif isinstance(to_delete, list):
        for item in to_delete:
            try:
                await bot.delete_message(chat_id=item['chat_id'], message_id=item['message_id'])
            except Exception:
                pass

    msg = await callback.message.answer(text='рассылка в процессе\n' + '⬜️' * 10)
    recievers = await get_users()
    rows_num = len(recievers)
    prev_blocks = 0
    for counter, user_id in enumerate(recievers, start=1):
        for _ in range(2):
            try:
                if notification_data.get('contains_album'):
                    await bot.send_media_group(chat_id=user_id, media=notification_data['file_id'])
                else:
                    await bot.copy_message(
                        chat_id=user_id,
                        from_chat_id=notification_data['msg_chat_id'],
                        message_id=notification_data['msg_message_id']
                    )
                break
            except TelegramRetryAfter as e:
                await asyncio.sleep(e.retry_after)
            except (TelegramForbiddenError, TelegramBadRequest):
                break
            except Exception:
                break

        # обновляем прогресс только когда меняется блок (10 обновлений на всю рассылку)
        blocks = int(counter / rows_num * 10)
        if blocks != prev_blocks or counter == rows_num:
            prev_blocks = blocks
            try:
                await msg.edit_text(
                    text=f'рассылка в процессе\n{"🟩" * blocks}{"⬜️" * (10 - blocks)} {counter}/{rows_num}'
                )
            except Exception:
                pass

        await asyncio.sleep(0.05)

    await msg.edit_text(text='Рассылка завершена✅')


@router.message(Command('ban'))
async def ban_user_cmd(message: Message) -> None:
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.answer('Использование: /ban &lt;id или @username&gt;')
        return

    arg = args[1].strip().lstrip('@')
    if arg.isdigit():
        tg_id = int(arg)
    else:
        tg_id = await get_id_by_username(arg)
        if not tg_id:
            await message.answer(f'Пользователь @{arg} не найден.')
            return

    if await ban_user(tg_id):
        await message.answer(f'Пользователь {tg_id} заблокирован.')
    else:
        await message.answer(f'Анкета {tg_id} не найдена.')


@router.message(Command('unban'))
async def unban_user_cmd(message: Message) -> None:
    args = message.text.split(maxsplit=1)
    if len(args) < 2:
        await message.answer('Использование: /unban &lt;id или @username&gt;')
        return

    arg = args[1].strip().lstrip('@')
    if arg.isdigit():
        tg_id = int(arg)
    else:
        tg_id = await get_id_by_username(arg)
        if not tg_id:
            await message.answer(f'Пользователь @{arg} не найден.')
            return

    if await unban_user(tg_id):
        await message.answer(f'Пользователь {tg_id} разблокирован.')
    else:
        await message.answer(f'Анкета {tg_id} не найдена.')


@router.callback_query(F.data == 'stats')
async def get_stats(callback: CallbackQuery) -> None:
    await callback.message.delete()
    ankets = await get_ankets_data()
    ankets_count = len(ankets)
    active_ankets_count = sum(1 for anket in ankets if anket[3])
    females_count = sum(1 for anket in ankets if not anket[0])
    males_count = sum(1 for anket in ankets if anket[0])
    active_females = sum(1 for anket in ankets if not anket[0] and anket[3])
    active_males = sum(1 for anket in ankets if anket[0] and anket[3])
    ages = [anket[1] for anket in ankets]
    middle_age = round(sum(ages) / len(ages)) if ages else 0
    cities_count = len({anket[2] for anket in ankets if anket[2]})
    await callback.message.answer(text=f'<b><i>Статистика пользователей бота:</i></b>\nВсего анкет: <b>{ankets_count}</b>, из них <b>{females_count}</b> тянок и <b>{males_count}</b> мужла\nАктивных анкет: <b>{active_ankets_count}</b>, из них <b>{active_females}</b> тянок и <b>{active_males}</b> мужла\nСредний возраст анкеты: <b>{middle_age}</b> лет\nКоличество уникальных указанных городов: <b>{cities_count}</b>')

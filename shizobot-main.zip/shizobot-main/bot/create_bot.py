from handlers import main_handlers, admin_panel

from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.redis import RedisStorage
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode

from decouple import config

# Получаем хост из .env, если нет — берем 'localhost' (для локального запуска без Docker)
redis_host = config('REDIS_HOST', default='localhost')
redis_port = config('REDIS_PORT', default='6379')
# redis_user = config('REDIS_USER', default='') # Если нужны логин/пароль
# redis_pass = config('REDIS_PASSWORD', default='')

# Формируем URL. Для простого Redis без пароля:
redis_url = f'redis://{redis_host}:{redis_port}/0'

# Если у вас есть пароль (в продакшене рекомендуется):
# redis_url = f'redis://:{redis_pass}@{redis_host}:{redis_port}/0'

bot = Bot(config('BOT_TOKEN'), default=DefaultBotProperties(parse_mode=ParseMode.HTML))
storage = RedisStorage.from_url(redis_url)
dp = Dispatcher(storage=storage)

def _parse_chat_id(value: str) -> int | str:
    v = value.strip()
    if v.lstrip('-').isdigit():
        return int(v)
    return v  # @username или просто username

required_chats: list[int | str] = [
    _parse_chat_id(x) for x in config('REQUIRED_CHATS', default='').split(',') if x.strip()
]

debug: bool = config('DEBUG', default=False, cast=bool)
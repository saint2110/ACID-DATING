import logging
import asyncio
from aiohttp import web

from handlers import admin_panel, main_handlers
from db.requests import get_admins
from create_bot import bot, dp

from aiogram.webhook.aiohttp_server import SimpleRequestHandler, setup_application
from aiogram.exceptions import TelegramForbiddenError, TelegramBadRequest
from aiogram import Bot

from decouple import config

# Настройка логирования
logs_format = '%(asctime)s - %(filename)s:%(lineno)d - %(message)s'
logging.basicConfig(level=logging.INFO, format=logs_format) # INFO для разработки, ERROR для продакшена

# --- Общие функции уведомлений ---

async def notify_admins_startup(bot: Bot):
    """Уведомление админов о запуске."""
    try:
        admins_ids = await get_admins()
        for id in admins_ids:
            try:
                await bot.send_message(chat_id=id, text='Бот запущен 🚀')
            except (TelegramForbiddenError, TelegramBadRequest):
                pass
    except Exception as e:
        logging.error(f"Error notifying admins on startup: {e}")

async def notify_admins_shutdown(bot: Bot):
    """Уведомление админов об остановке."""
    try:
        admins_ids = await get_admins()
        for id in admins_ids:
            try:
                await bot.send_message(chat_id=id, text='<b><i>Бот остановлен ❗</i></b>')
            except (TelegramForbiddenError, TelegramBadRequest):
                pass
    except Exception as e:
        logging.error(f"Error notifying admins on shutdown: {e}")

# --- Логика Webhook (для продакшена) ---

async def on_startup_webhook(bot: Bot) -> None:
    """Действия при старте в режиме Webhook."""
    await bot.set_webhook(
        f"{config('BASE_WEBHOOK_URL')}{config('WEBHOOK_PATH')}", 
        secret_token=config('WEBHOOK_SECRET')
    )
    await notify_admins_startup(bot)

async def on_shutdown_webhook(bot: Bot) -> None:
    """Действия при остановке в режиме Webhook."""
    await notify_admins_shutdown(bot)

def run_webhook():
    """Запуск бота в режиме Webhook."""
    dp.startup.register(on_startup_webhook)
    dp.shutdown.register(on_shutdown_webhook)
    
    app = web.Application()
    webhook_requests_handler = SimpleRequestHandler(
        dispatcher=dp,
        bot=bot,
        secret_token=config('WEBHOOK_SECRET'),
    )
    webhook_requests_handler.register(app, path=config('WEBHOOK_PATH'))
    setup_application(app, dp, bot=bot)
    
    web.run_app(app, host=config('WEB_SERVER_HOST', default='0.0.0.0'), port=config('WEB_SERVER_PORT', cast=int))

# --- Логика Polling (для разработки) ---

async def on_startup_polling(bot: Bot):
    """Действия при старте в режиме Polling."""
    # Удаляем вебхук, если он был установлен, чтобы бот получал обновления
    await bot.delete_webhook(drop_pending_updates=True)
    await notify_admins_startup(bot)

async def on_shutdown_polling(bot: Bot):
    """Действия при остановке в режиме Polling."""
    await notify_admins_shutdown(bot)

async def run_polling_async():
    """Асинхронная функция запуска Polling."""
    dp.startup.register(on_startup_polling)
    dp.shutdown.register(on_shutdown_polling)
    dp.include_routers(main_handlers.router, admin_panel.router)
    # Запускаем поллинг
    await dp.start_polling(bot)

def run_polling():
    """Точка входа для Polling."""
    try:
        asyncio.run(run_polling_async())
    except KeyboardInterrupt:
        logging.info("Bot stopped by user")

# --- Точка входа ---

if __name__ == "__main__":
    # Читаем режим работы из .env (по умолчанию polling)
    mode = config('BOT_MODE', default='polling').lower()
    
    logging.info(f"Starting bot in {mode} mode...")
    
    if mode == 'webhook':
        run_webhook()
    else:
        run_polling()
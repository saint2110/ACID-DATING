from decouple import config
import logging
import aiohttp  # Используем асинхронную библиотеку

server_adress = 'https://geocode-maps.yandex.ru/v1/?'

async def get_city_by_name(city):
    request_url = f'{server_adress}apikey={config("GEOCODER_APIKEY")}&geocode={city}&format=json'
    logging.info(request_url)
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(request_url) as resp:
                json_response = await resp.json()
                
                # Логируем ПОЛНЫЙ ответ, если в нем нет 'response' (это поможет понять ошибку)
                if "response" not in json_response:
                    logging.error(f"Geocoder API Error Response: {json_response}")
                    return None

                data = json_response["response"]["GeoObjectCollection"]["featureMember"]
                if not data:
                    return None
                
                city_name = data[0]["GeoObject"]["name"]
                return city_name if len(city_name) <= 32 else None

        except Exception as ex:
            logging.error(f"Geocoder request failed: {ex}")
            return None


async def get_city_by_cords(latitude, longitude):
    request_url = f'{server_adress}apikey={config("GEOCODER_APIKEY")}&geocode={longitude},{latitude}&format=json'
    logging.info(request_url)
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(request_url) as resp:
                json_response = await resp.json()

                if "response" not in json_response:
                    logging.error(f"Geocoder API Error Response: {json_response}")
                    return None

                feature_member = json_response["response"]["GeoObjectCollection"]["featureMember"]
                if not feature_member:
                    return None

                toponym = feature_member[0]["GeoObject"]["metaDataProperty"]
                administrative_area = toponym["GeocoderMetaData"]["AddressDetails"]["Country"]["AdministrativeArea"]
                
                if "SubAdministrativeArea" in administrative_area:
                    city_name = administrative_area["SubAdministrativeArea"]["Locality"]["LocalityName"]
                else:
                    city_name = administrative_area["Locality"]["LocalityName"]
                    
                return city_name if len(city_name) <= 32 else None

        except Exception as ex:
            logging.error(f"Geocoder request failed: {ex}")
            return None
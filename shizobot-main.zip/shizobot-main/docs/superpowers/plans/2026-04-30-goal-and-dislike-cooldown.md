# Goal Field + 24h Dislike Cooldown Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a goal-of-profile field (Friendship/Chat/Sex/Relationship) selectable during registration, displayed on profiles, plus a 24-hour cooldown on disliked profiles in the main search flow.

**Architecture:** Goal is stored as `SmallInteger nullable` in the `ankets` table, added as a new FSM step between `audio_request` and `anket_confirmation`. Dislike cooldown uses Redis keys with TTL=86400, checked per-profile inside the `show_next_anket` loop, written on 👎 press.

**Tech Stack:** Python 3.12, aiogram 3.x, SQLAlchemy async, Alembic, Redis (via `storage.redis` from `RedisStorage`)

**Spec:** `docs/superpowers/specs/2026-04-30-goal-and-dislike-cooldown-design.md`

---

## File Map

| File | Action | What changes |
|---|---|---|
| `bot/db/models.py` | Modify | Add `goal` field to `Anket` |
| `bot/db/requests.py` | Modify | Add `goal` param to `add_anket` |
| `bot/misc/states.py` | Modify | Add `goal_request` state |
| `bot/keyboards/main_keyboards.py` | Modify | Add `goal_request_kb()` |
| `bot/handlers/main_handlers.py` | Modify | Goal step, goal display, dislike cooldown |
| `bot/migration/versions/e1d9c8b7a6f5_.py` | Create | Alembic migration for `goal` column |

---

## Task 1: Alembic migration — add `goal` column

**Files:**
- Create: `bot/migration/versions/e1d9c8b7a6f5_.py`

- [ ] **Step 1: Create the migration file**

Create `bot/migration/versions/e1d9c8b7a6f5_.py` with this exact content:

```python
"""add goal to ankets

Revision ID: e1d9c8b7a6f5
Revises: c7a3e9d05f12
Create Date: 2026-04-30 00:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = 'e1d9c8b7a6f5'
down_revision: Union[str, None] = 'c7a3e9d05f12'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('ankets', sa.Column('goal', sa.SmallInteger(), nullable=True))


def downgrade() -> None:
    op.drop_column('ankets', 'goal')
```

- [ ] **Step 2: Apply the migration**

Run from the `bot/` directory (where `alembic.ini` lives):

```bash
cd /Users/katya/shizobot/bot && alembic upgrade head
```

Expected output ends with: `Running upgrade c7a3e9d05f12 -> e1d9c8b7a6f5, add goal to ankets`

- [ ] **Step 3: Verify column exists**

```bash
# Connect to your postgres DB and check
psql $DB_URL -c "\d ankets" | grep goal
```

Expected: `goal | smallint | | |`

- [ ] **Step 4: Commit**

```bash
git add bot/migration/versions/e1d9c8b7a6f5_.py
git commit -m "feat: add goal column migration to ankets"
```

---

## Task 2: Update SQLAlchemy model

**Files:**
- Modify: `bot/db/models.py`

- [ ] **Step 1: Add `goal` field to `Anket` class**

In `bot/db/models.py`, after the `audio_file_id` line (line 22), add:

```python
    goal: Mapped[int | None] = mapped_column(SmallInteger, nullable=True)
```

The full `Anket` class now looks like:

```python
class Anket(Base):
    __tablename__ = 'ankets'
    id: Mapped[int] = mapped_column(BigInteger, primary_key=True)
    username: Mapped[str | None] = mapped_column(String(34), nullable=True)
    name: Mapped[str] = mapped_column(String(32), nullable=False)
    age: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    male: Mapped[bool] = mapped_column(Boolean, nullable=False)
    interest: Mapped[int] = mapped_column(SmallInteger, nullable=False)
    city: Mapped[str] = mapped_column(String(32), nullable=True)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    banned: Mapped[bool] = mapped_column(Boolean, default=False)
    audio_file_id: Mapped[str | None] = mapped_column(String(96), nullable=True)
    goal: Mapped[int | None] = mapped_column(SmallInteger, nullable=True)
```

- [ ] **Step 2: Commit**

```bash
git add bot/db/models.py
git commit -m "feat: add goal field to Anket model"
```

---

## Task 3: Update `add_anket` in requests.py

**Files:**
- Modify: `bot/db/requests.py` lines 47–55

- [ ] **Step 1: Add `goal` parameter to `add_anket`**

Replace the existing `add_anket` function (lines 47–55) with:

```python
@async_connection
async def add_anket(session: AsyncSession, tg_id: int, username: str | None, name: str, age: int,
                    gender: bool, interest: int, city: str, description: str, status: bool,
                    audio_file_id: str | None = None, goal: int | None = None) -> None:
    logging.info(f'add_anket: {tg_id=} {name=} {age=} {gender=} {city=}')
    anket = Anket(id=tg_id, username=username, name=name, age=age, male=gender, interest=interest,
                  city=city, description=description, active=status, audio_file_id=audio_file_id,
                  goal=goal)
    await session.merge(anket)
    await session.commit()
    _ac_del(tg_id)
```

- [ ] **Step 2: Commit**

```bash
git add bot/db/requests.py
git commit -m "feat: add goal param to add_anket"
```

---

## Task 4: Add FSM state and keyboard

**Files:**
- Modify: `bot/misc/states.py`
- Modify: `bot/keyboards/main_keyboards.py`

- [ ] **Step 1: Add `goal_request` state to `RegistrationSteps`**

In `bot/misc/states.py`, add `goal_request` between `audio_request` and `anket_confirmation`:

```python
class RegistrationSteps(StatesGroup):
    start = State()
    age_request = State()
    gender_request = State()
    interest_request = State()
    location_request = State()
    name_request = State()
    description_request = State()
    media_request = State()
    media_confirmation = State()
    audio_request = State()
    goal_request = State()
    anket_confirmation = State()
```

- [ ] **Step 2: Add `goal_request_kb()` to keyboards**

In `bot/keyboards/main_keyboards.py`, add this function after `audio_request_kb()`:

```python
def goal_request_kb() -> ReplyKeyboardMarkup:
    kb = ReplyKeyboardBuilder()
    kb.add(KeyboardButton(text='🤝 Дружба'))
    kb.add(KeyboardButton(text='💬 Общение'))
    kb.add(KeyboardButton(text='🔥 Секс'))
    kb.add(KeyboardButton(text='💑 Отношения'))
    kb.add(KeyboardButton(text='пропустить цель ⏩'))
    kb.adjust(2, 2, 1)
    return kb.as_markup(resize_keyboard=True)
```

- [ ] **Step 3: Commit**

```bash
git add bot/misc/states.py bot/keyboards/main_keyboards.py
git commit -m "feat: add goal_request state and keyboard"
```

---

## Task 5: Update handlers — goal registration step + display

**Files:**
- Modify: `bot/handlers/main_handlers.py`

### 5a — Add GOAL_LABELS constant and update imports

- [ ] **Step 1: Add `goal_request_kb` to keyboard import and add GOAL_LABELS constant**

At the top of `bot/handlers/main_handlers.py`, the keyboards import line already does `from keyboards.main_keyboards import *` so `goal_request_kb` is automatically available.

After the `router.message.middleware(AlbumMiddleware())` line (line 21), add:

```python
GOAL_LABELS = {
    0: '🤝 Дружба',
    1: '💬 Общение',
    2: '🔥 Секс',
    3: '💑 Отношения',
}
GOAL_BUTTONS = {v: k for k, v in GOAL_LABELS.items()}
```

`GOAL_BUTTONS` maps button text → integer value for the handler.

### 5b — Add `goal_request_step` helper and handler

- [ ] **Step 2: Add `goal_request_step` helper**

Add this function directly after `audio_request_step` (after line ~352):

```python
async def goal_request_step(message: Message, state: FSMContext) -> None:
    """Запрос цели анкеты"""
    await state.set_state(RegistrationSteps.goal_request)
    await message.answer(
        '🎯 Выбери цель знакомства:',
        reply_markup=goal_request_kb()
    )
```

- [ ] **Step 3: Add `handle_goal_request` handler**

Add this handler directly after `handle_audio_request` (after line ~370):

```python
GOAL_BUTTON_TEXTS = set(GOAL_LABELS.values()) | {'пропустить цель ⏩'}

@router.message(F.text.in_(GOAL_BUTTON_TEXTS), StateFilter(RegistrationSteps.goal_request))
async def handle_goal_request(message: Message, state: FSMContext) -> None:
    """Обработка выбора цели анкеты"""
    goal = GOAL_BUTTONS.get(message.text)  # None если пропустить
    await state.update_data(goal=goal)
    await anket_confirmation(message=message, state=state)
```

### 5c — Redirect audio handler to goal step

- [ ] **Step 4: Update `handle_audio_request` to call `goal_request_step`**

In `handle_audio_request`, replace every call to `anket_confirmation` with `goal_request_step`.

Currently (lines ~358–370):
```python
    if message.content_type == ContentType.TEXT and message.text in ('пропустить музыку ⏩', 'удалить музыку 🗑'):
        await state.update_data(audio_file_id=None)
        await anket_confirmation(message=message, state=state)   # ← change this

    elif message.content_type == ContentType.AUDIO:
        if message.audio.file_size > AUDIO_SIZE_LIMIT:
            await message.answer('Файл слишком большой, максимум 20 МБ. Попробуй ещё раз.')
            return
        await state.update_data(audio_file_id=message.audio.file_id)
        await anket_confirmation(message=message, state=state)   # ← change this
```

Replace both calls with `goal_request_step`:

```python
@router.message(StateFilter(RegistrationSteps.audio_request))
async def handle_audio_request(message: Message, state: FSMContext) -> None:
    """Обработка загрузки музыки при регистрации"""
    if message.content_type == ContentType.TEXT and message.text in ('пропустить музыку ⏩', 'удалить музыку 🗑'):
        await state.update_data(audio_file_id=None)
        await goal_request_step(message=message, state=state)

    elif message.content_type == ContentType.AUDIO:
        if message.audio.file_size > AUDIO_SIZE_LIMIT:
            await message.answer('Файл слишком большой, максимум 20 МБ. Попробуй ещё раз.')
            return
        await state.update_data(audio_file_id=message.audio.file_id)
        await goal_request_step(message=message, state=state)

    else:
        await message.answer('Пришли MP3-файл или нажми «пропустить музыку ⏩».')
```

### 5d — Update `anket_confirmation` preview to show goal

- [ ] **Step 5: Add goal line to `anket_confirmation` preview**

In `anket_confirmation` (around line 376), find this line:

```python
    anket_text = f'{main_info} – {html.escape(description)}'
```

Replace it with:

```python
    goal = data.get('goal')
    goal_text = f'\n🎯 {GOAL_LABELS[goal]}' if goal is not None else ''
    anket_text = f'{main_info} – {html.escape(description)}{goal_text}'
```

### 5e — Update `render_anket` to show goal

- [ ] **Step 6: Add goal line to `render_anket`**

In `render_anket` (around line 145), find this line:

```python
    anket_text = f'{pre_text}{html.escape(anket.name)}, {anket.age}{city} - {html.escape(anket.description)}{after_text}{admin_info}'
```

Replace it with:

```python
    goal_text = f'\n🎯 {GOAL_LABELS[anket.goal]}' if anket.goal is not None else ''
    anket_text = f'{pre_text}{html.escape(anket.name)}, {anket.age}{city} - {html.escape(anket.description)}{goal_text}{after_text}{admin_info}'
```

### 5f — Pass `goal` when saving anket

- [ ] **Step 7: Pass `goal` in `anket_saving`**

In `anket_saving` handler (around line 405), find the `add_anket` call:

```python
    await add_anket(tg_id=message.from_user.id, username=message.from_user.username,
                    name=data['name'], age=data['age'], gender=data['gender'],
                    interest=data['interest'], city=data['city'], description=data['description'],
                    status=status, audio_file_id=data.get('audio_file_id'))
```

Replace with:

```python
    await add_anket(tg_id=message.from_user.id, username=message.from_user.username,
                    name=data['name'], age=data['age'], gender=data['gender'],
                    interest=data['interest'], city=data['city'], description=data['description'],
                    status=status, audio_file_id=data.get('audio_file_id'),
                    goal=data.get('goal'))
```

- [ ] **Step 8: Commit all handler changes so far**

```bash
git add bot/handlers/main_handlers.py
git commit -m "feat: add goal registration step and profile display"
```

---

## Task 6: 24h dislike cooldown

**Files:**
- Modify: `bot/handlers/main_handlers.py`

- [ ] **Step 1: Import `storage` from `create_bot`**

In `bot/handlers/main_handlers.py`, find the existing import line:

```python
from create_bot import required_chats, debug
```

Replace with:

```python
from create_bot import required_chats, debug, storage
```

- [ ] **Step 2: Update `show_next_anket` to skip disliked profiles**

In `show_next_anket`, find the while loop:

```python
    while anket_id := await get_anket_from_queue(message.from_user.id, state):
        result = await render_anket(anket_id, message, admin_view=admin_view)
        if result is True:
            await state.update_data(processing=anket_id)
            return
        if result is None:
            return
```

Replace with:

```python
    while anket_id := await get_anket_from_queue(message.from_user.id, state):
        if await storage.redis.exists(f'dislike:{message.from_user.id}:{anket_id}'):
            continue
        result = await render_anket(anket_id, message, admin_view=admin_view)
        if result is True:
            await state.update_data(processing=anket_id)
            return
        if result is None:
            return
```

- [ ] **Step 3: Update `case '👎'` in `search` handler to write Redis key**

In `search` handler, find:

```python
        case '👎': await show_next_anket(message, state) # дизлайк
```

Replace with:

```python
        case '👎':
            data = await state.get_data()
            processing = data.get('processing')
            if processing:
                await storage.redis.setex(f'dislike:{message.from_user.id}:{processing}', 86400, '1')
            await show_next_anket(message, state)
```

- [ ] **Step 4: Commit**

```bash
git add bot/handlers/main_handlers.py
git commit -m "feat: 24h dislike cooldown via Redis TTL keys"
```

---

## Task 7: Manual verification

- [ ] **Step 1: Start the bot in polling mode and go through full registration**

Verify in order:
1. `/start` → fill out all steps through audio
2. After audio step → bot asks "🎯 Выбери цель знакомства:" with 5 buttons
3. Tap a goal (e.g. "🔥 Секс") → preview shows `\n🎯 🔥 Секс` at the bottom of the profile text
4. Tap "пропустить цель ⏩" → preview shows no goal line
5. Confirm anket → goes to main menu

- [ ] **Step 2: Verify goal displays in search**

1. Have another account with a profile
2. Start search — their profile shows goal at the bottom if they set one
3. Profile with no goal set (existing profile, `goal=null`) shows nothing after description — no crash

- [ ] **Step 3: Verify 24h dislike cooldown**

1. In search, tap 👎 on a profile
2. That profile should not appear again in this session
3. To verify Redis key: `redis-cli GET "dislike:{your_tg_id}:{disliked_tg_id}"` → returns `"1"`
4. Check TTL: `redis-cli TTL "dislike:{your_tg_id}:{disliked_tg_id}"` → returns a number close to 86400

- [ ] **Step 4: Verify likes mode is unaffected**

In likes mode (someone liked you, you view their profile), tapping 👎 removes the like as before — no Redis key written, the profile can still appear in main search.

# Design: Goal Edit (without re-registration)

Date: 2026-04-30

## Goal

Allow users to change their profile goal (Friendship/Chat/Sex/Relationship) from the edit menu without re-filling the entire profile.

## Pattern

Identical to existing `description_edit` and `audio_edit` flows.

## Changes

### `bot/keyboards/main_keyboards.py`

Add `'6'` button to `edit_anket_kb()`. Update `kb.adjust(4, 1, 1)` → `kb.adjust(4, 1, 1, 1)`:

```python
def edit_anket_kb() -> ReplyKeyboardMarkup:
    kb = ReplyKeyboardBuilder()
    kb.add(KeyboardButton(text='1🚀'))
    kb.add(KeyboardButton(text='2'))
    kb.add(KeyboardButton(text='3'))
    kb.add(KeyboardButton(text='4'))
    kb.add(KeyboardButton(text='5'))
    kb.add(KeyboardButton(text='6'))
    kb.add(KeyboardButton(text='🔗 Получить VPN'))
    kb.adjust(4, 1, 1, 1)
    return kb.as_markup(resize_keyboard=True)
```

### `bot/misc/states.py`

Add `goal_edit = State()` to `MainStates` after `audio_edit`.

### `bot/db/requests.py`

New function after `change_anket_audio`:

```python
@async_connection
async def change_anket_goal(session: AsyncSession, tg_id: int, goal: int | None) -> None:
    user = await session.scalar(select(Anket).filter_by(id=tg_id))
    if not user:
        return
    user.goal = goal
    await session.merge(user)
    await session.commit()
    _ac_del(tg_id)
```

### `bot/handlers/main_handlers.py`

**`start_search_or_edit_anket`** — update decorator filter to include `'6'`:
```python
@router.message(F.text.in_(('1🚀', '2', '3', '4', '5', '6')), StateFilter(MainStates.edit_anket_or_start))
```
And add `case '6'`:
```python
case '6':
    await state.set_state(MainStates.goal_edit)
    await message.answer('Выбери новую цель знакомства:', reply_markup=goal_request_kb())
```

Menu text update — add `'6. Изменить цель 🎯'` to the answer string in `show_self_anket` and `anket_saving`.

**New handler** after `anket_audio_edit`:
```python
@router.message(F.text.in_(GOAL_BUTTON_TEXTS), StateFilter(MainStates.goal_edit))
async def anket_goal_edit(message: Message, state: FSMContext) -> None:
    goal = GOAL_BUTTONS.get(message.text)  # None for пропустить
    await change_anket_goal(tg_id=message.from_user.id, goal=goal)
    await show_self_anket(message=message, state=state)


@router.message(StateFilter(MainStates.goal_edit))
async def anket_goal_edit_fallback(message: Message, state: FSMContext) -> None:
    await message.answer('Выбери цель из кнопок ниже 👇', reply_markup=goal_request_kb())
```

## No DB migration needed

Column `goal` already exists from previous feature.

## Files touched

| File | Change |
|---|---|
| `bot/keyboards/main_keyboards.py` | Add button 6, update adjust() |
| `bot/misc/states.py` | Add `goal_edit` to MainStates |
| `bot/db/requests.py` | Add `change_anket_goal` |
| `bot/handlers/main_handlers.py` | case '6', menu text, two new handlers |

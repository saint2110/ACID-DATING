# Design: Goal Field + 24h Dislike Cooldown

Date: 2026-04-30

## Feature 1: Цель анкеты (Goal Field)

### Цель
Пользователь выбирает цель создания анкеты на финальном шаге регистрации. Цель отображается внизу анкеты с эмодзи. Можно пропустить.

### База данных
- Новое поле `goal: SmallInteger, nullable=True` в таблице `ankets`
- Значения: `0=Дружба`, `1=Общение`, `2=Секс`, `3=Отношения`, `null=не выбрано`
- Одна Alembic-миграция, ALTER TABLE ADD COLUMN с DEFAULT NULL

### Константа в хэндлерах
```python
GOAL_LABELS = {
    0: '🤝 Дружба',
    1: '💬 Общение',
    2: '🔥 Секс',
    3: '💑 Отношения',
}
```

### Поток регистрации
До: `audio_request → anket_confirmation`
После: `audio_request → goal_request → anket_confirmation`

- Новый state: `RegistrationSteps.goal_request`
- `handle_audio_request` вызывает `goal_request_step` вместо `anket_confirmation`
- Новый хэндлер `handle_goal_request` принимает кнопку цели или «пропустить ⏩», сохраняет `goal: int | None` в FSM-data, вызывает `anket_confirmation`

### Клавиатура `goal_request_kb()`
```
[ 🤝 Дружба ] [ 💬 Общение ] [ 🔥 Секс ] [ 💑 Отношения ]
[              пропустить ⏩              ]
```
Кнопки: строки `'🤝 Дружба'`, `'💬 Общение'`, `'🔥 Секс'`, `'💑 Отношения'`, `'пропустить цель ⏩'`
Layout: `kb.adjust(2, 2, 1)`

### Отображение в render_anket
```python
goal_text = f'\n🎯 {GOAL_LABELS[anket.goal]}' if anket.goal is not None else ''
anket_text = f'{pre_text}{name}, {age}{city} - {description}{goal_text}{after_text}{admin_info}'
```
Та же логика в `anket_confirmation` превью — через `data.get('goal')`.

### add_anket / модель
- `add_anket` получает новый параметр `goal: int | None = None`
- `Anket` модель: `goal: Mapped[int | None] = mapped_column(SmallInteger, nullable=True)`
- При вызове `anket_saving` передаётся `goal=data.get('goal')`

### Существующие анкеты
`goal=null` → строка цели не отображается. Никаких дополнительных миграций данных не нужно.

---

## Feature 2: 24ч дизлайк кулдаун

### Цель
Если пользователь ставит 👎 в основном поиске, анкета не показывается ему снова в течение 24 часов. Не затрагивает режим просмотра лайков.

### Хранилище
Redis (уже в стеке). Ключ: `dislike:{viewer_id}:{target_id}`, TTL=86400 сек.
Доступ: `storage.redis` (импорт `storage` из `create_bot`).

### Запись дизлайка
В `search` хэндлере, `case '👎'`:
```python
case '👎':
    data = await state.get_data()
    processing = data.get('processing')
    if processing:
        await storage.redis.setex(f'dislike:{message.from_user.id}:{processing}', 86400, '1')
    await show_next_anket(message, state)
```

### Фильтрация
В `show_next_anket`, внутри `while`-цикла сразу после получения `anket_id`:
```python
while anket_id := await get_anket_from_queue(message.from_user.id, state):
    if await storage.redis.exists(f'dislike:{message.from_user.id}:{anket_id}'):
        continue
    result = await render_anket(anket_id, message, admin_view=admin_view)
    ...
```

### Область применения
- ✅ Основной поиск (`MainStates.search`, кнопка 👎)
- ❌ Режим лайков (`MainStates.likes_answer`) — не затрагивается

---

## Затрагиваемые файлы

| Файл | Изменения |
|---|---|
| `bot/db/models.py` | Новое поле `goal` в `Anket` |
| `bot/db/requests.py` | Параметр `goal` в `add_anket` |
| `bot/misc/states.py` | Новый state `RegistrationSteps.goal_request` |
| `bot/keyboards/main_keyboards.py` | Новая `goal_request_kb()` |
| `bot/handlers/main_handlers.py` | Новый шаг, рендер цели, дизлайк-кулдаун |
| `bot/migration/versions/<new>.py` | ALTER TABLE ankets ADD COLUMN goal |

## Нет изменений в
- `admin_panel.py` — не нужно
- `docker-compose.yml`, `nginx.conf` — не нужно
- Существующие миграции — только новый файл
